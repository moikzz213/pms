<?php

namespace App\Models;

use App\Models\Log;
use App\Models\Company;
use App\Models\Profile;
use App\Models\Requests;
use App\Models\Department;
use Laravel\Sanctum\HasApiTokens;
use App\Models\Local_purchase_order;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $guarded = [];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function profile()
    {
        return $this->hasOne(Profile::class);
    } 

    public function lpos()
    {
        return $this->hasMany(Local_purchase_order::class);
    }

    public function pafs()
    {
        return $this->hasMany(Payment_approval_form::class);
    }

    public function requests()
    {
        return $this->hasMany(Requests::class, 'process_by', 'id');
    }

    public function logs()
    {
        return $this->morphToMany(Log::class, 'loggable');
    }
} 